def expected_value(prob, odds):
    """EV = p * k - 1"""
    return prob * odds - 1
