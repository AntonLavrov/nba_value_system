// components/filters.js

export function renderFilters(teams, onChange) {
    const panel = document.createElement("div");
    panel.className = "filter-panel";

    // Team selector
    const teamLabel = document.createElement("label");
    teamLabel.textContent = "Team: ";

    const teamSelect = document.createElement("select");
    teamSelect.id = "team-filter";

    const optAll = document.createElement("option");
    optAll.value = "All";
    optAll.textContent = "All";
    teamSelect.appendChild(optAll);

    teams.forEach(t => {
        const o = document.createElement("option");
        o.value = t;
        o.textContent = t;
        teamSelect.appendChild(o);
    });

    // Min edge filter
    const edgeLabel = document.createElement("label");
    edgeLabel.textContent = "Min edge (abs): ";

    const edgeInput = document.createElement("input");
    edgeInput.type = "number";
    edgeInput.id = "min-edge-filter";
    edgeInput.value = 0;
    edgeInput.min = 0;

    // callback
    teamSelect.addEventListener("change", () => onChange());
    edgeInput.addEventListener("input", () => onChange());

    // Add to panel
    panel.appendChild(teamLabel);
    panel.appendChild(teamSelect);

    panel.appendChild(edgeLabel);
    panel.appendChild(edgeInput);

    document.body.insertBefore(panel, document.querySelector("table"));
}

/**
 * Apply filters to game list.
 *  - team filter
 *  - minimum edge filter
 */
export function applyFilters(data) {
    const team = document.getElementById("team-filter").value;
    const minEdge = Number(document.getElementById("min-edge-filter").value);

    return data.filter(g => {
        let ok = true;

        if (team !== "All") {
            ok = ok && (g.home === team || g.away === team);
        }

        const edgeAbs = Math.max(Math.abs(g.edge_home || 0), Math.abs(g.edge_away || 0));
        ok = ok && edgeAbs >= minEdge;
        return ok;
    });
}
